package dev.gr1.db.dao;

import dev.gr1.Main;
import dev.gr1.db.bind.*;
import dev.gr1.proj.GeldType;
import dev.gr1.proj.GeldUtils;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;

public class ProjektVersionDao extends Dao<ProjektVersion> {
    public ProjektVersionDao(Connection connection, Class<ProjektVersion> clazz) throws SQLException {
        super(connection, clazz);
    }

    public void deleteVersion(int versionId) throws SQLException {
        ProjektVersion version = select(versionId);

        List<Geld> privatGeld = GeldUtils.allGeld(version.privatID, GeldType.Privat);
        GeldUtils.deleteAll(privatGeld);
        Dao<Privat> privatDao = Main.DB.dao();
        privatDao.delete(version.privatID);

        List<Geld> ertragGeld = GeldUtils.allGeld(version.ertragID, GeldType.Ertrag);
        GeldUtils.deleteAll(ertragGeld);
        Dao<Ertrag> ertragDao = Main.DB.dao();
        ertragDao.delete(version.ertragID);

        List<Geld> kapitalGeld = GeldUtils.allGeld(version.kapitalID, GeldType.Kapital);
        GeldUtils.deleteAll(kapitalGeld);
        Dao<Kapital> kapitalDao = Main.DB.dao();
        kapitalDao.delete(version.kapitalID);

        List<Geld> finanzierungGeld = GeldUtils.allGeld(version.finanzierungID, GeldType.Finanzierung);
        GeldUtils.deleteAll(finanzierungGeld);
        Dao<Finanzierung> finanzierungDao = Main.DB.dao();
        finanzierungDao.delete(version.finanzierungID);

        List<Geld> kostenGeld = GeldUtils.allGeld(version.kostenID, GeldType.Kosten);
        GeldUtils.deleteAll(kostenGeld);
        Dao<Privat> kostenDao = Main.DB.dao();
        kostenDao.delete(version.kostenID);

        delete(version);
    }
}
